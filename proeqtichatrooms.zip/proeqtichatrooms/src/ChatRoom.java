import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

public class ChatRoom {
    private ServerSocket serverSocket;
    private final ConcurrentHashMap<String, ObjectOutputStream> connectedClients = new ConcurrentHashMap<>();

    public void start(int port) {
        try {
            serverSocket = new ServerSocket(port);
            System.out.println("ChatRoom server started on port " + port);

            while (true) {
                Socket socket = serverSocket.accept();
                System.out.println("New client connected: " + socket);

                Thread thread = new Thread(new ClientHandler(socket));
                thread.start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private class ClientHandler implements Runnable {
        private final Socket socket;
        private ObjectInputStream inputStream;
        private ObjectOutputStream outputStream;
        private String username;

        public ClientHandler(Socket socket) {
            this.socket = socket;
        }

        public void run() {
            try {
                outputStream = new ObjectOutputStream(socket.getOutputStream());
                inputStream = new ObjectInputStream(socket.getInputStream());

                sendMessage("Welcome to the chat!");

                username = (String) inputStream.readObject();
                connectedClients.put(username, outputStream);

                broadcast(username + " has joined the chat. Total users: " + connectedClients.size());

                while (true) {
                    Object received = inputStream.readObject();
                    if (received instanceof String) {
                        String message = (String) received;
                        if (message.equalsIgnoreCase("/exit")) {
                            break;
                        } else if (message.startsWith("/private")) {

                            String[] parts = message.split(" ", 3);
                            if (parts.length == 3) {
                                String recipient = parts[1];
                                String privateMsg = parts[2];
                                sendPrivateMessage(username, recipient, privateMsg);
                            }
                        } else if (message.startsWith("/name")) {

                            String[] parts = message.split(" ", 2);
                            if (parts.length == 2) {
                                String newName = parts[1];
                                String oldName = username;
                                username = newName;
                                connectedClients.put(newName, outputStream);
                                connectedClients.remove(oldName);
                                broadcast(oldName + " changed their name to " + newName);
                            }
                        } else {

                            broadcast(username + ": " + message);
                        }
                    }
                }
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            } finally {

                connectedClients.remove(username);
                broadcast(username + " has left the chat. Total users: " + connectedClients.size());

                try {
                    socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        private void sendMessage(String message) throws IOException {
            outputStream.writeObject(message);
            outputStream.flush();
        }

        private void broadcast(String message) {
            for (ObjectOutputStream clientStream : connectedClients.values()) {
                try {
                    clientStream.writeObject(message);
                    clientStream.flush();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        private void sendPrivateMessage(String sender, String recipient, String message) {
            ObjectOutputStream recipientStream = connectedClients.get(recipient);
            if (recipientStream != null) {
                try {
                    recipientStream.writeObject("[Private message from " + sender + "]: " + message);
                    recipientStream.flush();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
