import java.io.*;
import java.net.*;
import java.util.Scanner;
public class ChatUser {
    private Socket socket;
    private ObjectInputStream inputStream;
    private ObjectOutputStream outputStream;
    private String username;

    public void start(String address, int port) {
        try {
            socket = new Socket(address, port);
            System.out.println("Connected to ChatRoom at " + address + ":" + port);

            outputStream = new ObjectOutputStream(socket.getOutputStream());
            inputStream = new ObjectInputStream(socket.getInputStream());

            String welcomeMessage = (String) inputStream.readObject();
            System.out.println(welcomeMessage);

            Scanner scanner = new Scanner(System.in);
            System.out.println("Enter your username:");
            username = scanner.nextLine();
            outputStream.writeObject(username);
            outputStream.flush();

            Thread sendMessageThread = new Thread(() -> {
                try {
                    while (true) {
                        String message = scanner.nextLine();
                        outputStream.writeObject(message);
                        outputStream.flush();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });
            sendMessageThread.start();

            while (true) {
                Object received = inputStream.readObject();
                if (received instanceof String) {
                    String message = (String) received;
                    System.out.println(message);
                }
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}