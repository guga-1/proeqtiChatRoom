import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        ChatRoom chatRoom = new ChatRoom();

        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the port number:");

        int port = scanner.nextInt();

        chatRoom.start(port);

        ChatUser chatUser = new ChatUser();

        System.out.println("Enter the server address:");

        String address = scanner.nextLine();

        System.out.println("Enter the server port number:");

        chatUser.start(address, port);
    }
}
